from send_mail import mail
from sys import argv
if __name__ == '__main__':
  mail("Job:: %s has failed" %argv[1],"Job:: %s has failed.\nPlease see logs at %s\n\t and at %s" % (argv[1],argv[2],argv[3]))
