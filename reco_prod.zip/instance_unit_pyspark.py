from pyspark.sql.types import *
from pyspark import SparkContext
from pyspark import SQLContext
def oritentData(record):
  record = record.split(',')
  indexes = [1,2,7,11,5,8,20]
  return [ record[i].replace('"','') for i in indexes]

def filterData(record):
  flag = True
  if (int(record[3])<1 == flag) or (record[5] not in (['1','4'])) or (record[-1] != ''): flag = False
  return flag

if __name__ == '__main__':
  sc = SparkContext(appName = 'RecorDataPreparation')
  sqlContext = SQLContext(sc)
  in_file = sc.textFile('file:///home/reco1/data/prod_sales/ProductSales_20130404.csv')
  data = in_file.map(oritentData).filter(filterData).map(lambda x: [int(i) for i in x[:-3]])
  schema = StructType([ StructField('customer_id',IntegerType(),True),
  StructField('product_id',IntegerType(),True),StructField('invoice_id',IntegerType(),True),StructField('units',IntegerType(),True)])
  df = sqlContext.createDataFrame(data,schema)
  sqlContext.registerDataFrameAsTable(df,'table1')
  df_instances = sqlContext.sql('select customer_id, product_id, count(invoice_id) as prod_in_transactions from table1 group by customer_id, product_id')
  df_instances.map(lambda x: ','.join([str(r) for r in x])).saveAsTextFile('/user/reco1/data/algoinput/instances')
  sc.stop()

  
