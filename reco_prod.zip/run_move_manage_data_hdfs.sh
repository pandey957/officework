source ./params 

log_date=`date +"%Y%m%d%H%M%S"`
jobname=`echo $0 | cut -d'.' -f1`

spark_log_warn=$log_path$jobname'_warn_'$log_date.log
spark_log_error=$log_path$jobname'_error_'$log_date.log

msg=`ls -lSr $in_unix_files_path  | tail -1 | cut -d" " -f5,9 | awk '{print "File: "$2", Size: ",$1}'`

python job_started.py $jobname "$msg"

hdfs dfs -put $in_unix_files_path*.csv $in_hdfs_data_path 2> $spark_log_warn >> $spark_log_error

if [ $? -ne 0 ]; then
  python job_failed.py $jobname $spark_log_warn $spark_log_error
  exit 1
fi


files=`hdfs dfs -ls $in_hdfs_data_path | wc -l` 2> $spark_log_warn >> $spark_log_error

if [ $files -gt $weeks ]; then
  file_to_remove=`hdfs dfs -ls $in_hdfs_data_path | sort -k 6,7 | head -2 | tail -1 | cut -d" " -f11`
  hdfs dfs -rm $file_to_remove 2> $spark_log_warn >> $spark_log_error
fi

if [ $? -ne 0 ]; then
  python job_failed.py $jobname $spark_log_warn $spark_log_error
  exit 1
else
  python job_complete.py $jobname
fi

