source ./params

if [ ! -f $file_check ];then
  exit 1
fi

sh run_move_manage_data_hdfs.sh # Move incremental file to hdfs staging area

if [ $? -ne 0 ];then
  exit 1
fi

sh run_data_prep.sh mba_date_view.py

[ $? -ne 0 ] && exit 1

sh run_data_prep.sh cf-transcation_spark_job.py

[ $? -ne 0 ] && exit 1

sh run_data_prep.sh cf-units_spark_job.py

if [ $? -eq 0 ]; then
  log_date=`date +"%Y%m%d%H%M%S"`
  for file in $in_unix_files_path*.csv; do temp_file=`basename $file`; mv $file $processed$temp_file_$log_date; done
  rm $file_check
else
  exit 1
fi

