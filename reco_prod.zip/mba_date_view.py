from pyspark.sql.types import *
from pyspark import SparkContext
from pyspark import SQLContext
import sys
def oritentData(record):
  record = record.split(',')
  indexes = [2,5,7,8,11,20]
  return [ record[i].replace('"','') for i in indexes]

def filterData(record):
  flag = True
  if (int(record[4])<1) or (record[3] not in (['1','4'])) or (record[-1] != ''): flag = False
  return flag

if __name__ == '__main__':
  sc = SparkContext(appName = 'RecorDataPreparation')
  sqlContext = SQLContext(sc)
  in_file = sc.textFile(sys.argv[1])
  data = in_file.map(oritentData).filter(filterData).map(lambda x: [i for i in x[:3]]).map(lambda x: ','.join(x))
  data.saveAsTextFile(sys.argv[2])
  sc.stop()

  
