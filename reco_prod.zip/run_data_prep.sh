source ./params

if [ $# -lt 1 ];then
  echo 'Error: Please provide full arguments'
  exit 1
fi

script_file=$1

log_date=`date +"%Y%m%d%H%M%S"`

jobname=`echo $0 | cut -d'.' -f1`
prog_name=`echo $1 | cut -d'_' -f1`
jobname=$jobname'_'$prog_name

spark_log_warn=$log_path$jobname'_warn_'$log_date.log
spark_log_error=$log_path$jobname'_error_'$log_date.log

out_hdfs_data_path=$out_hdfs_data_path$prog_name

python job_started.py $jobname 

hdfs dfs -test -d $out_hdfs_data_path

if [ $? -eq 0 ]; then 
  hdfs dfs -rm -r $out_hdfs_data_path 2> $spark_log_warn  >> $spark_log_error
fi

spark-submit --master yarn --deploy-mode cluster $script_file $in_hdfs_data_path*.csv  $out_hdfs_data_path 2> $spark_log_warn  >> $spark_log_error

if [ $? -ne 0 ]; then
  python job_failed.py $jobname $spark_log_warn $spark_log_error
  exit 1
else
  python job_complete.py $jobname
fi
