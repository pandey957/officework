from envelopes import Envelope
import smtplib
def mail(subject,msg,sender='satyendra.pandey@annik.com',receiver='satyendra.pandey@annik.com'):
  envelope = Envelope(
    from_addr = sender, 
    to_addr = receiver,
    subject = subject,
    text_body = msg)
  envelope.send('smtp.office365.com', login=sender,password='@August957', tls=True)


