from send_mail import mail
from sys import argv
from time import time,gmtime, strftime

if __name__ == '__main__':
  msg = 'Your job: %s has started at %s'%(argv[0], strftime("%Y-%m-%d %H:%M:%S", gmtime()))
  if len(argv)>2:
    msg = msg + '\nFile received with following details:\n\t' + argv[2]
  mail("Job:: %s has started" % argv[1],msg)
