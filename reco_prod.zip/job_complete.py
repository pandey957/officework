from send_mail import mail
from sys import argv
from time import time,gmtime, strftime

if __name__ == '__main__':
  mail("Job::%s has completed" % argv[1],'Your job: %s has completed at %s'%(argv[1], strftime("%Y-%m-%d %H:%M:%S", gmtime())))
